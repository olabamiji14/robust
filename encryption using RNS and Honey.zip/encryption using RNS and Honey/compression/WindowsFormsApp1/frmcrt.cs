﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmcrt : Form
    {
        public frmcrt()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch sw = new Stopwatch();



            // Start The StopWatch ...From 000

            sw.Start();
            int n = int.Parse(textBox2.Text);
            if (textBox2.Text == "")
            {

                MessageBox.Show("ENTER YOUR DECIPHER KEY FOR THE MESSAGE ID" + view.id);




            }



            else if ((textBox1.TextLength < 3) || (textBox1.TextLength > 5))
            {
                MessageBox.Show("INVALID KEY");

            }

            else
            {
                String newid = view.id;
                string myConnection = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");

                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand command = myConn.CreateCommand();
                command.CommandText = "Select  *  FROM decipherkey WHERE msgid = '" + newid + "' && nvalue = '" + this.textBox2.Text + "' &&  dkey = '" + this.textBox1.Text + "' ";
                MySqlDataReader myReader;

                myConn.Open();
                myReader = command.ExecuteReader();
                if (myReader.Read())


                {
                    // newid = view.id;
                    string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");

                    MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                    MySqlCommand command1 = myConn1.CreateCommand();
                    command1.CommandText = "Select  *  FROM encryptedmessage WHERE msgid = '" + newid + "' ";
                    MySqlDataReader myReader1;

                    myConn1.Open();
                    myReader1 = command1.ExecuteReader();
                    while (myReader1.Read())
                    {
                        string message = myReader1["encrypted_message"].ToString();
                        textBox3.Text = message;

                        string[] result = new string[message.Length];
                        char[] temp = new char[message.Length];
                        char word;
                        temp = message.ToCharArray();
                        int n0, t;
                        //moduli set
                        double[] y = new double[3];
                        y[0] = Math.Pow(2, n) - 1; 
                        y[1] = Math.Pow(2, n);
                        y[2] = Math.Pow(2, n) + 1;
                        int a = Convert.ToInt32(y[0]);
                        int b = Convert.ToInt32(y[1]);
                        int c = Convert.ToInt32(y[2]);
                        int h = Convert.ToInt32(2);
                        textBox4.Text = h.ToString();
                        // richTextBox3.Text = (message.Length/3).ToString();
                        getdnumber();
                        int m = 0;
                        for (int i = 0; i <= message.Length - 1; i += 3)
                        {
                            
                            char c1 = (temp[i]);
                            char c2 = (temp[i + 1]);
                            char c3 = (temp[i + 2]);

                            int r1 = ((int)(c1) - 48);
                            int r2 = ((int)(c2) - 48);
                            int r3 = ((int)(c3) - 48);


                            RemainderProblem.Solve(a, b, c, r1, r2, r3, out n0, out t);
                            //textBox3.Text =  result[i] + result[i + 1] + result[i + 2]; // spliting messages into array of characters
                            // textBox3.Text = n0.ToString();
                            listBoxN.Items.Clear();
                            for (int j = 0; j < 20; j++)
                            {
                                listBoxN.Items.Add(n0 + t * j);

                            }
                            listBoxN.Items.Add("...");
                            //  int n1 = Convert.ToInt32 (listBoxN.Items[1]);

                            /* if (n1 < 1575) {
                                  n1 = Convert.ToInt32(listBoxN.Items[1]);

                             }
                             */
                           

                            

                                int n1 = Convert.ToInt32(listBox1.Items[m]);



                                 n0 = n1;
                                //char word = (char)(n1);
                                word = ' ';

                                richTextBox2.Text = richTextBox2.Text + "\n" + n0.ToString();
                                if (n1 == 11)
                                {
                                    word = 'ا';
                                    richTextBox1.Text = richTextBox1.Text + "a";
                                }
                                else if (n1 == 13)

                                {
                                    word = 'ب';
                                    richTextBox1.Text = richTextBox1.Text + "b";

                                }

                                else if (n1 == 15)

                                {
                                    word = 'ت';
                                    richTextBox1.Text = richTextBox1.Text + "c";

                                }
                                else if (n1 == 17)

                                {
                                    word = 'ث';
                                    richTextBox1.Text = richTextBox1.Text + "d";

                                }
                                else if (n1 == 19)

                                {
                                    word = 'ج';
                                    richTextBox1.Text = richTextBox1.Text + "e";

                                }
                                else if (n1 == 21)

                                {
                                    word = 'ح';
                                    richTextBox1.Text = richTextBox1.Text + "f";

                                }
                                else if (n1 == 23)

                                {
                                    word = 'خ';
                                    richTextBox1.Text = richTextBox1.Text + "g";

                                }
                                else if (n1 == 25)

                                {
                                    word = 'د';
                                    richTextBox1.Text = richTextBox1.Text + "h";

                                }
                                else if (n1 == 27)

                                {
                                    word = 'ذ';
                                    richTextBox1.Text = richTextBox1.Text + "i";

                                }
                                else if (n1 == 29)

                                {
                                    word = 'ر';
                                    richTextBox1.Text = richTextBox1.Text + "j";

                                }
                                else if (n1 == 31)

                                {
                                    word = 'ز';
                                    richTextBox1.Text = richTextBox1.Text + "k";

                                }

                                else if (n1 == 33)
                                {
                                    word = 'س';
                                    richTextBox1.Text = richTextBox1.Text + "l";

                                }
                                else if (n1 == 35)
                                {
                                    word = 'ش';
                                    richTextBox1.Text = richTextBox1.Text + "m";

                                }
                                else if (n1 == 37)

                                {
                                    word = 'ص';
                                    richTextBox1.Text = richTextBox1.Text + "n";

                                }
                                else if (n1 == 39)

                                {

                                    word = 'ض';
                                    richTextBox1.Text = richTextBox1.Text + "o";

                                }
                                else if (n1 == 41)

                                {
                                    word = 'ط';
                                    richTextBox1.Text = richTextBox1.Text + "p";

                                }
                                else if (n1 == 43)

                                {
                                    word = 'ظ';
                                    richTextBox1.Text = richTextBox1.Text + "q";

                                }
                                else if (n1 == 45)

                                {
                                    word = 'ع';
                                    richTextBox1.Text = richTextBox1.Text + "r";

                                }
                                else if (n1 == 47)
                                {
                                    word = 'غ';
                                    richTextBox1.Text = richTextBox1.Text + "s";

                                }
                                else if (n1 == 49)
                                {
                                    word = 'ف';
                                    richTextBox1.Text = richTextBox1.Text + "t";

                                }
                                else if (n1 == 51)
                                {
                                    word = 'ق';
                                    richTextBox1.Text = richTextBox1.Text + "u";

                                }
                                else if (n1 == 53)
                                {
                                    word = 'ك';
                                    richTextBox1.Text = richTextBox1.Text + "v";

                                }
                                else if (n1 == 55)
                                {
                                    word = 'ل';
                                    richTextBox1.Text = richTextBox1.Text + "w";

                                }
                                else if (n1 == 57)
                                {
                                    word = 'م';
                                    richTextBox1.Text = richTextBox1.Text + "x";

                                }
                                else if (n1 == 59)
                                {
                                    word = 'ن';
                                    richTextBox1.Text = richTextBox1.Text + "y";

                                }
                                else if (n1 == 61)
                                {
                                    word = 'ة';
                                    richTextBox1.Text = richTextBox1.Text + "z";

                                }
                                else
                                {
                                    richTextBox1.Text = richTextBox1.Text + word.ToString();
                                }


                            m++;
                            /*if ( word == 'ا')
                            
                            
                            {
                                richTextBox1.Text = richTextBox1.Text + "a";
                            }
                             else if (word == 'ب')
                            {
                                richTextBox1.Text = richTextBox1.Text + "b";

                            }

                            else if (word == 'ت')
                            {
                                richTextBox1.Text = richTextBox1.Text + "c";

                            }

                               else if (word == 'ث')
                            {
                                richTextBox1.Text = richTextBox1.Text + "d";

                            }
                            else if (word == 'ج')
                            {
                                richTextBox1.Text = richTextBox1.Text + "e";

                            }
                            else if (word == 'ح')
                            {
                                richTextBox1.Text = richTextBox1.Text + "f";

                            }
                            else if (word == 'خ')
                            {
                                richTextBox1.Text = richTextBox1.Text + "g";

                            }
                            else if (word == 'د')
                            {
                                richTextBox1.Text = richTextBox1.Text + "h";

                            }
                            else if (word == 'ذ')
                            {
                                richTextBox1.Text = richTextBox1.Text + "i";

                            }
                            else if (word == 'ر')
                            {
                                richTextBox1.Text = richTextBox1.Text + "j";

                            }
                            else if (word == 'ز')
                            {
                                richTextBox1.Text = richTextBox1.Text + "k";

                            }
                            else if (word == 'س')
                            {
                                richTextBox1.Text = richTextBox1.Text + "l";

                            }
                            else if (word == 'ش')
                            {
                                richTextBox1.Text = richTextBox1.Text + "m";

                            }

                            else if (word == 'ص')
                            {
                                richTextBox1.Text = richTextBox1.Text + "n";

                            }
                            
                            else if (word == 'ض')
                            {
                                richTextBox1.Text = richTextBox1.Text + "o";

                            }
                            else if (word == 'ط')
                            {
                                richTextBox1.Text = richTextBox1.Text + "p";

                            }
                            else if (word == 'ظ')
                            {
                                richTextBox1.Text = richTextBox1.Text + "q";

                            }
                            else if (word == 'ع')
                            {
                                richTextBox1.Text = richTextBox1.Text + "r";

                            }
                            else if (word == 'غ')
                            {
                                richTextBox1.Text = richTextBox1.Text + "s";

                            }
                            else if (word == 'ف')
                            {
                                richTextBox1.Text = richTextBox1.Text + "t";

                            }
                            else if (word == 'ق')
                            {
                                richTextBox1.Text = richTextBox1.Text + "u";

                            }
                            else if (word == 'ك')
                            {
                                richTextBox1.Text = richTextBox1.Text + "v";

                            }
                            else if (word == 'ل')
                            {
                                richTextBox1.Text = richTextBox1.Text + "w";

                            }
                            else if (word == 'م')
                            {
                                richTextBox1.Text = richTextBox1.Text + "x";

                            }
                            else if (word == 'ن')
                            {
                                richTextBox1.Text = richTextBox1.Text + "y";

                            }
                            else if (word == 'ة')
                            {
                                richTextBox1.Text = richTextBox1.Text + "z";

                            }
                            else
                            {
                                richTextBox1.Text = richTextBox1.Text + word.ToString();
                            }
                            */
                        }
                    }


                    myConn1.Close();
                }

                // implementing honey algorithm
                else
                {
                    string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
                    // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
                    MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                    MySqlCommand command1 = myConn1.CreateCommand();
                    command1.CommandText = "Select  *  FROM message WHERE msgid = '" + newid + "' ";
                    MySqlDataReader myReader1;

                    myConn1.Open();
                    myReader1 = command1.ExecuteReader();
                    while (myReader1.Read())
                    {

                        Random ran = new Random();
                        string cipher_text;
                        

                        string phrase = myReader1["message"].ToString();
                        string[] words = phrase.Split(' ');

                       
                            int seedvalue = ran.Next(0, words.Length);
                        
                            cipher_text = words[seedvalue];
                        textBox5.Text = seedvalue.ToString();
                            string myConnection3 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
                            // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
                            MySqlConnection myConn3 = new MySqlConnection(myConnection3);
                            MySqlCommand command3 = myConn3.CreateCommand();
                            command3.CommandText = "Select  *  FROM honeydictionary WHERE secretwords = '" + cipher_text + "' ";
                            MySqlDataReader myReader3;

                            myConn3.Open();
                            myReader3 = command3.ExecuteReader();
                            while (myReader3.Read())
                            {
                            words[seedvalue] = myReader3["honeyword"].ToString();
                            foreach (var word in words)
                            {

                                richTextBox1.Text = richTextBox1.Text + " " + word.ToString();
                            }

                            }
                        //    richTextBox1.Text = richTextBox1.Text + '\n'+($"{word}");



                        /*  int k = myReader1["message"].ToString().Length;
                        int j = k ;
                        //richTextBox1.MaxLength=  50;
                        string message = myReader1["message"].ToString();
                        string[] result = new string[message.Length];
                        char[] temp = new char[message.Length];

                        temp = message.ToCharArray();

                        for (int i = 0; i <= j - 1; i++)
                        {
                            result[i] = Convert.ToString(temp[i]);
                            richTextBox1.Text = richTextBox1.Text + result[i]; 


                        }*/
                        myConn3.Close();

                        // richTextBox1.Text = myReader1["message"].ToString() + richTextBox1.MaxLength;
                    }


                    myConn1.Close();

                }


                myConn.Close();
                string ExecutionTimeTaken = string.Format("Minutes :{0}\nSeconds :{1}\n Mili seconds :{2}", sw.Elapsed.Minutes, sw.Elapsed.Seconds, sw.Elapsed.TotalMilliseconds);
                label6.Text = ExecutionTimeTaken;
                sw.Stop();
            }
        }

        public void honey()
        {
            
        }


        private void getdnumber()
        {
            String newid = view.id;
            string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
            // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
            MySqlConnection myConn1 = new MySqlConnection(myConnection1);
            MySqlCommand command1 = myConn1.CreateCommand();
            command1.CommandText = "Select  *  FROM message WHERE msgid = '" + newid + "' ";
            MySqlDataReader myReader1;

            myConn1.Open();
            myReader1 = command1.ExecuteReader();
            while (myReader1.Read())
            {
              
                //richTextBox1.MaxLength=  50;
                string message = myReader1["dnumber"].ToString();
                string[] result = new string[message.Length];
                char[] temp = new char[message.Length];

                temp = message.ToCharArray();

                for (int i = 0; i <= message.Length-1; i+=2)
                {
                    // result[i] = Convert.ToString(temp[i]);
                   // richTextBox3.Text = message.Length.ToString();
                   //  richTextBox3.Text = richTextBox3.Text + "\n" + temp[i].ToString() + temp[i + 1].ToString(); // spliting messages into array of characters
                    listBox1.Items.Add(temp[i].ToString() + temp[i + 1].ToString());



                }


                // richTextBox1.Text = myReader1["message"].ToString() + richTextBox1.MaxLength;
            }


            myConn1.Close();
        }
            
        private void frmcrt_Load(object sender, EventArgs e)
        {

        }
    }
}
