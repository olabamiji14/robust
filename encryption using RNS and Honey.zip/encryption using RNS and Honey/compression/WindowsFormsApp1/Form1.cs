﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmsplash : Form
    {
        public frmsplash()
        {
            InitializeComponent();
        }

        private void frmsplash_Load(object sender, EventArgs e)
        {
            timeleft = 20;
            timer1.Start();
        }
        public int timeleft { get; set; }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeleft > 0)
            {

                timeleft = timeleft - 1;

            }

            else

            {

                timer1.Stop();

                new frmlogin().Show();

                this.Hide();
            }
        }
    }
}
