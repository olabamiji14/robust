﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmmessage : Form
    {


        public static string msgid, msg, userid;
        public static int pvkey;
        public frmmessage()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {



            String newid = view.id;
            string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
            // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
            MySqlConnection myConn1 = new MySqlConnection(myConnection1);
            MySqlCommand command1 = myConn1.CreateCommand();
            command1.CommandText = "Select  *  FROM register WHERE userid = '" + this.textBox1.Text + "' ";
            MySqlDataReader myReader1;

            myConn1.Open();
            myReader1 = command1.ExecuteReader();
            if (myReader1.Read())
            {
                int n = int.Parse(textBox5.Text);
                double[] y = new double[3] { (Math.Pow(2, n) - 1), (Math.Pow(2, n)),  (Math.Pow(2, n) + 1) };
                textBox3.Text = y[0].ToString() + y[1].ToString() + y[2].ToString();
                insertdb();
                msg = richTextBox1.Text;
                new frmcompress().Show();
                myConn1.Close();
                userid = textBox1.Text;


            }
            else
            {
                MessageBox.Show("The recipient is invalid","ENCRYPTION");

            }


                    // richTextBox1.Text = myReader1["message"].ToString() + richTextBox1.MaxLength;
                


                


            
         

            
           
        }

        public void insertdb()
        {
            MySqlConnection con = new MySqlConnection("Server=localhost; User Id=root; Password=; Database=encryptionhoney");
            MySqlCommand cmd, cmd2;


            try
            {
                if (textBox1.Text.Length > 0 && textBox2.Text.Length > 0)
                {


                    string CmdString = "INSERT INTO message(msgid,receiver, subject,  sender, message) VALUES(@msgid, @receiver, @subject, @sender, @message)";
                    cmd = new MySqlCommand(CmdString, con);

                    string CmdString2 = "INSERT INTO decipherkey(msgid,dkey, nvalue) VALUES(@msgid, @dkey, @nv)";
                    cmd2 = new MySqlCommand(CmdString2, con);


                    cmd2.Parameters.Add("@msgid", MySqlDbType.Int32, 5);
                    cmd2.Parameters.Add("@dkey", MySqlDbType.Int32, 5);
                    cmd2.Parameters.Add("@nv", MySqlDbType.Int32, 5);

                    cmd.Parameters.Add("@msgid", MySqlDbType.VarChar, 5);
                    cmd.Parameters.Add("@receiver", MySqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@subject", MySqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@sender", MySqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@message", MySqlDbType.VarChar, 500);
                    /* cmd.Parameters.Add("@othername", MySqlDbType.VarChar, 30);
                    
                     */
                    cmd2.Parameters["@msgid"].Value = msgid;
                    cmd2.Parameters["@dkey"].Value = textBox3.Text;
                    cmd2.Parameters["@nv"].Value = textBox5.Text;


                    cmd.Parameters["@msgid"].Value = msgid;
                    cmd.Parameters["@receiver"].Value = textBox1.Text;
                    cmd.Parameters["@subject"].Value = textBox2.Text;
                    cmd.Parameters["@sender"].Value = textBox4.Text;
                    cmd.Parameters["@message"].Value = richTextBox1.Text;
                    /*;*/
                    con.Open();
                    /* mysname = textBox2.Text;

     */
                    int RowsAffected = cmd.ExecuteNonQuery();
                    int RowsAffected2 = cmd2.ExecuteNonQuery();
                    if (RowsAffected > 0 && RowsAffected2 > 0)
                    {
                        MessageBox.Show("Message  sent sucessfully!");
                      //  textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        pvkey = int.Parse(textBox5.Text);


                    }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Incomplete data!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (MySqlException mex)
            {
                MessageBox.Show(mex.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        private void frmmessage_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int i = r.Next(10, 20);
            int j = r.Next(21, 90);
            int k = r.Next(1, 9);
             msgid = i.ToString() + j.ToString() + k.ToString() ;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
