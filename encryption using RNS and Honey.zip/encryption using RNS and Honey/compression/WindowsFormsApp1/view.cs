﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using MySql.Data.MySqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class view : Form
    {
        public static string id;
        public view()
        {
            InitializeComponent();
        }

        private void view_Load(object sender, EventArgs e)
        {
            string sql = "SELECT msgid, encrypted_message FROM encryptedmessage Where userid ='" + frmlog2.userid + "'";
            //string sql = "SELECT ProfilCode, ProfilName FROM Profils";
            DataTable myTable = new DataTable();

            using (MySqlConnection connection = new MySqlConnection("Server=localhost; User Id=root; Password=; Database=encryptionhoney"))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(sql, connection))
                {
                    adapter.Fill(myTable);
                }
            }

            dataGridView1.DataSource = myTable;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)

        {

            MessageBox.Show(dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());

            id = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();

            new frmcrt().Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
