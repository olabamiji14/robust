﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using MySql.Data.MySqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmreg : Form
    {
        public frmreg()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            insertdb();



        }


        public void insertdb()
        {
            MySqlConnection con = new MySqlConnection("Server=localhost; User Id=root; Password=; Database=encryptionhoney");
            MySqlCommand cmd;


            try
            {
                if (textBox1.Text.Length > 0 && textBox2.Text.Length > 0)
                {


                    string CmdString = "INSERT INTO register(name, userid, password) VALUES(@name, @mail, @pass)";
                    cmd = new MySqlCommand(CmdString, con);

                    cmd.Parameters.Add("@name", MySqlDbType.VarChar, 45);
                    cmd.Parameters.Add("@mail", MySqlDbType.VarChar, 30);
                    cmd.Parameters.Add("@pass", MySqlDbType.VarChar, 30);
                    /* cmd.Parameters.Add("@othername", MySqlDbType.VarChar, 30);
                     cmd.Parameters.Add("@add", MySqlDbType.VarChar, 30);
                     cmd.Parameters.Add("@phone", MySqlDbType.VarChar, 15);
                     cmd.Parameters.Add("@sex", MySqlDbType.VarChar, 10);
                     cmd.Parameters.Add("@occup", MySqlDbType.VarChar, 30);
                     cmd.Parameters.Add("@state", MySqlDbType.VarChar, 30);
                     cmd.Parameters.Add("@lga", MySqlDbType.VarChar, 50);
                     cmd.Parameters.Add("@birth", MySqlDbType.VarChar, 50);
                     cmd.Parameters.Add("@Image", MySqlDbType.Blob);
                     cmd.Parameters.Add("@ward", MySqlDbType.Int32, 3);
                     */
                    cmd.Parameters["@name"].Value = textBox1.Text;
                    cmd.Parameters["@mail"].Value = textBox2.Text;
                    cmd.Parameters["@pass"].Value = textBox3.Text;
                    /*cmd.Parameters["@othername"].Value = txtoname.Text;
                    cmd.Parameters["@add"].Value = txtaddress.Text;
                    cmd.Parameters["@phone"].Value = txtphone.Text;
                    cmd.Parameters["@sex"].Value = cbosex.Text;
                    cmd.Parameters["@occup"].Value = txtoccupation.Text;
                    cmd.Parameters["@state"].Value = cbostate.Text;
                    cmd.Parameters["@lga"].Value = cbolga.Text;
                    cmd.Parameters["@birth"].Value = dateTimePicker1;
                    cmd.Parameters["@Image"].Value = ImageData;
                    cmd.Parameters["@ward"].Value = txtward.Text;*/
                    con.Open();
                    /* mysname = textBox2.Text;
                     myfname = txtfname.Text;
                     myoname = txtoname.Text;
                     myid = textBox1.Text;
                     myadd = txtaddress.Text;
                     mylga = cbolga.Text;
                     mystate = cbostate.Text;
                     myoccupation = txtoccupation.Text;
                     mysex = cbosex.Text;
                     myward = txtward.Text;
                     mypic = pictureBox3.Image;

     */
                    int RowsAffected = cmd.ExecuteNonQuery();
                    if (RowsAffected > 0)
                    {
                        MessageBox.Show("Record Captured sucessfully!");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";

                    }
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Incomplete data!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (MySqlException mex)
            {
                MessageBox.Show(mex.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}