﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmread : Form
    {
        public frmread()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") {

                MessageBox.Show("ENTER YOUR DECIPHER KEY FOR THE MESSAGE ID" + view.id );


            

}



            else if ((textBox1.TextLength < 3 ) || (textBox1.TextLength > 5))
            {
                MessageBox.Show("THE  DECIPHER KEY LENGTH FOR THE MESSAGE ID" + view.id + "DOES NOT MATCH" );

            }

            else
            {
                String newid = view.id;
                string myConnection = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
                //string myConnection = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
                MySqlConnection myConn = new MySqlConnection(myConnection);
                MySqlCommand command = myConn.CreateCommand();
                command.CommandText = "Select  *  FROM decipherkey WHERE msgid = '" + newid + "' &&  dkey ='" + textBox1.Text + "' ";
                MySqlDataReader myReader;

                myConn.Open();
                myReader = command.ExecuteReader();
                if (myReader.Read())

                
                {
                   // newid = view.id;
                    string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
                   // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
                   MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                    MySqlCommand command1 = myConn1.CreateCommand();
                    command1.CommandText = "Select  *  FROM message WHERE msgid = '" + newid + "' ";
                    MySqlDataReader myReader1;

                   myConn1.Open();
                    myReader1 = command1.ExecuteReader();
                    while (myReader1.Read())
                    {
                        richTextBox1.Text = myReader1["message"].ToString();
                    }


                   myConn1.Close();
                }

                // implementing honey algorithm
                else {
                    string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
                    // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
                    MySqlConnection myConn1 = new MySqlConnection(myConnection1);
                    MySqlCommand command1 = myConn1.CreateCommand();
                    command1.CommandText = "Select  *  FROM message WHERE msgid = '" + newid + "' ";
                    MySqlDataReader myReader1;

                    myConn1.Open();
                    myReader1 = command1.ExecuteReader();
                    while (myReader1.Read())
                    {
                       int k = myReader1["message"].ToString().Length ;
                        int j = k / 2;
                      //richTextBox1.MaxLength=  50;
                        string message = myReader1["message"].ToString();
                        string[] result = new string[message.Length];
                        char[] temp = new char[message.Length];

                        temp = message.ToCharArray();

                        for (int i = 0; i <= j - 1; i++)
                        {
                            result[i] = Convert.ToString(temp[i]);
                            richTextBox1.Text = richTextBox1.Text +  result[i]; // spliting messages into array of characters


                        }


                       // richTextBox1.Text = myReader1["message"].ToString() + richTextBox1.MaxLength;
                    }


                    myConn1.Close();

                }

                myConn.Close();



            }
               
        }

        private void frmread_Load(object sender, EventArgs e)
        {

        }
    }
}
