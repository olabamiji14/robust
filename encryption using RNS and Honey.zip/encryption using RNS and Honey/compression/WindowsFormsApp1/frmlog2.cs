﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmlog2 : Form
    {
        public static string userid;
        public frmlog2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string myConnection1 = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
            // string myConnection1 = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
            MySqlConnection myConn1 = new MySqlConnection(myConnection1);
            MySqlCommand command1 = myConn1.CreateCommand();
            command1.CommandText = "Select  *  FROM register WHERE userid = '" + this.textBox1.Text + "' &&  password = '" + this.textBox2.Text + "'";
            MySqlDataReader myReader1;

            myConn1.Open();
            myReader1 = command1.ExecuteReader();
            if (myReader1.Read())
            {

                //richTextBox1.MaxLength=  50;
                
                userid= myReader1["userid"].ToString();
                
            
                myConn1.Close();
                new view().Show();

            }

            else {

                MessageBox.Show("Wrong Log in Credentials","ENCRYPTION");
            }

                // richTextBox1.Text = myReader1["message"].ToString() + richTextBox1.MaxLength;
            }


          
        }
    }

