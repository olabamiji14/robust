﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmtableen : Form
    {
        public static string newid, message1;
        public frmtableen()
        {
            InitializeComponent();
        }

        private void frmtableen_Load(object sender, EventArgs e)
        {

            /* newid = view.id;
             string myConnection = ("Server=localhost; User Id=root; Password=; Database= encryptionhoney");
             //string myConnection = ("Server=localhost; User Id=root; Password=; Database=biometricvoting");
             MySqlConnection myConn = new MySqlConnection(myConnection);
             MySqlCommand command = myConn.CreateCommand();
             command.CommandText = "Select  *  FROM message WHERE msgid = '" + newid + "' ";
             MySqlDataReader myReader;

             myConn.Open();
             myReader = command.ExecuteReader();
             while (myReader.Read()) {
                 message1 = myReader["message"].ToString();
             }


             myConn.Close(); */

            

            usetable();

        }

        public void usetable()

        {
          // panel.MaximumSize = new Size(450, 1000);
           // panel.AutoScroll = true;
            panel.RowCount = 1;
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            panel.Controls.Add(new Label() { Text = "Character" }, 0, 0);
            panel.Controls.Add(new Label() { Text = "Arabic Text" }, 1, 0);
            panel.Controls.Add(new Label() { Text = "Decimal No" }, 2, 0);
            panel.Controls.Add(new Label() { Text = "RNS " }, 3, 0);


            //encryption
            //string message =message1;
            string message = "abcdefghijklmnopqrstuvwxyz1234567890";

            int n = 9;

            string[] result = new string[message.Length];
            char[] temp = new char[message.Length];

            temp = message.ToCharArray();

            for (int i = 0; i <= message.Length - 1; i++)
            {
                result[i] = Convert.ToString(temp[i]);
                // int x = (int)temp[i];
                //richTextBox3.Text = richTextBox3.Text + "\n" + x.ToString();

                if ((result[i] == "a") || (result[i] == "A"))
                { // Arabic equivalent of each character
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ا" }, 1, panel.RowCount - 1);

                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ا";

                    int x = (int)('ا');
                   // string y = x.ToString();
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];

                    
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                  //  richTextBox4.Text = richTextBox4.Text + "\n" + MOD1.ToString() + MOD2.ToString() + MOD3.ToString();
                   // richTextBox3.Text = richTextBox3.Text + "\n" + x.ToString();
                    // ENCRYPTING TEXT
                    //textBox1.Text = textBox1.Text + MOD1.ToString() + MOD2.ToString() + MOD3.ToString();

                }

                else if ((result[i] == "b") || (result[i] == "B"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ب" }, 1, panel.RowCount - 1);

                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ب";
                    int x = (int)('ب');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }


                else if ((result[i] == "c") || (result[i] == "C"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ت" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ت";
                    int x = (int)('ت');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "D") || (result[i] == "d"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ث" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ث";
                    int x = (int)('ث');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "e") || (result[i] == "E"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ج" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ج";
                    int x = (int)('ج');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }
                else if ((result[i] == "f") || (result[i] == "F"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ح" }, 1, panel.RowCount - 1);
                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ح";
                    int x = (int)('ح');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "g") || (result[i] == "G"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "خ" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "خ";
                    int x = (int)('خ');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }
                else if ((result[i] == "h") || (result[i] == "H"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "د" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "د";
                    int x = (int)('د');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "i") || (result[i] == "I"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ذ" }, 1, panel.RowCount - 1);
                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ذ";
                    int x = (int)('ذ');
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "j") || (result[i] == "J"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ر" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ر";
                    int x = (int)('ر'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "k") || (result[i] == "K"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ز" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ز";
                    int x = (int)('ز'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "l") || (result[i] == "L"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "س" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "س";

                    int x = (int)('س'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }
                else if ((result[i] == "m") || (result[i] == "M"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ش" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ش";
                    int x = (int)('ش'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "N") || (result[i] == "n"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ص" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ص";

                    int x = (int)('ص'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }


                else if ((result[i] == "o") || (result[i] == "O"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ض" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ض";

                    int x = (int)('ض'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "p") || (result[i] == "P"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ط" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ط";

                    int x = (int)('ط'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "q") || (result[i] == "Q"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ظ" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ظ";

                    int x = (int)('ظ'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "r") || (result[i] == "R"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ع" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ع";

                    int x = (int)('ع'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "s") || (result[i] == "S"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "غ" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "غ";

                    int x = (int)('غ'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "t") || (result[i] == "T"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ف" }, 1, panel.RowCount - 1);
                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ف";

                    int x = (int)('ف'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }
                else if ((result[i] == "u") || (result[i] == "U"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ق" }, 1, panel.RowCount - 1);
                  //  richTextBox2.Text = richTextBox2.Text + "\n" + "ق";

                    int x = (int)('ق'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "v") || (result[i] == "V"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ك" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ك";

                    int x = (int)('ك'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "w") || (result[i] == "W"))
                {
                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ل" }, 1, panel.RowCount - 1);

                   // richTextBox2.Text = richTextBox2.Text + "\n" + "ل";


                    int x = (int)('ل'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "x") || (result[i] == "X"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "م" }, 1, panel.RowCount - 1);

                    //richTextBox2.Text = richTextBox2.Text + "\n" + "م";

                    int x = (int)('م'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);

                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "y") || (result[i] == "Y"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ن" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ن";

                    int x = (int)('ن'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "z") || (result[i] == "Z"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "ة" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('ة'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "1") )
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "١" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('١'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "2"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٢" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٢'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "3"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٣" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٣'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "4"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٤" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٤'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "5"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٥" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٥'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "6"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٦" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٦'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "7"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٧" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٧'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "8"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٨" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٨'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else if ((result[i] == "9"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٩" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٩'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }

                else if ((result[i] == "0"))
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = "٠" }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + "ة";

                    int x = (int)('٠'); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);
                }
                else
                {

                    panel.RowCount = panel.RowCount + 1;
                    panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
                    panel.Controls.Add(new Label() { Text = result[i] }, 1, panel.RowCount - 1);
                    //richTextBox2.Text = richTextBox2.Text + "\n" + result[i];


                    int x = (int)(temp[i]); // converting arabic letters to its decimal equivalent using the ascii unicode
                    panel.Controls.Add(new Label() { Text = x.ToString() }, 2, panel.RowCount - 1);
                    double[] y = new double[3] { (Math.Pow(2, n) + 1), (Math.Pow(2, n)), (Math.Pow(2, n) - 1) };
                    // int RNS1 = x / 3; // implementation of RNS

                    double MOD1 = x % y[0];


                    //int RNS2 = x / 3;
                    double MOD2 = x % y[1];

                    // textBox1.Text = RNS2.ToString();
                    // int RNS3 = x - (RNS1 + RNS2);
                    //textBox1.Text = RNS3.ToString();
                    double MOD3 = x % y[2];
                    panel.Controls.Add(new Label() { Text = MOD1.ToString() + MOD2.ToString() + MOD3.ToString() }, 3, panel.RowCount - 1);

                }
                panel.Controls.Add(new Label() { Text = result[i] }, 0, panel.RowCount - 1);
                //richTextBox1.Text = richTextBox1.Text + "\n" + result[i]; // spliting messages into array of characters


            

            
        }




    }
    }


}
