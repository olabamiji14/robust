-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2020 at 05:50 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `encryptionhoney`
--

-- --------------------------------------------------------

--
-- Table structure for table `decipherkey`
--

CREATE TABLE `decipherkey` (
  `msgid` int(5) NOT NULL,
  `dkey` int(5) NOT NULL,
  `nvalue` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `decipherkey`
--

INSERT INTO `decipherkey` (`msgid`, `dkey`, `nvalue`) VALUES
(17835, 345, 2);

-- --------------------------------------------------------

--
-- Table structure for table `encryptedmessage`
--

CREATE TABLE `encryptedmessage` (
  `msgid` int(5) NOT NULL,
  `encrypted_message` varchar(2000) NOT NULL,
  `userid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `encryptedmessage`
--

INSERT INTO `encryptedmessage` (`msgid`, `encrypted_message`, `userid`) VALUES
(17835, '114110032232202032232202114110134202231211211013032030231114032034112', 'queengold');

-- --------------------------------------------------------

--
-- Table structure for table `honeydictionary`
--

CREATE TABLE `honeydictionary` (
  `seed` int(5) NOT NULL,
  `honeyword` varchar(50) NOT NULL,
  `secretwords` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `honeydictionary`
--

INSERT INTO `honeydictionary` (`seed`, `honeyword`, `secretwords`) VALUES
(1, 'account', 'matric'),
(2, 'matric', 'account'),
(3, 'name', 'number'),
(4, 'number', 'name'),
(5, 'application', 'website'),
(6, 'website', 'application'),
(7, 'Mr', 'Mrs'),
(8, 'miss', 'Mrs'),
(9, 'Mrs', 'Mr'),
(10, 'Office', 'Hostel'),
(11, 'Hostel', 'Car park'),
(12, 'faculty', 'department'),
(13, 'department', 'admin block'),
(14, 'Vice chancellor', 'Deputy V.C'),
(15, 'Registar', 'Vice chancellor'),
(16, 'Deputy VC', 'VC'),
(17, 'Busar', 'V.C'),
(18, 'HOD', 'Lecturer'),
(19, 'class rep', 'students'),
(20, 'those', 'this'),
(21, 'wasn\'t', 'is'),
(22, 'computer', 'app'),
(23, 'her', 'my'),
(24, 'his', 'her'),
(25, 'less busy', 'busy'),
(26, 'website', 'program'),
(27, 'hosting', 'testing'),
(28, 'last week', 'week'),
(29, 'go to', 'Hello'),
(30, 'before', 'today'),
(31, 'implementation', 'Honey'),
(32, 'comparison', 'hybridization'),
(33, 'Genetic', 'RNS'),
(34, 'excluding', 'and'),
(35, 'class work', 'test'),
(36, 'Dr', 'miss'),
(37, 'Abdul', 'Giwa'),
(38, 'not a', 'the');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `msgid` int(5) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `sender` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL,
  `dnumber` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`msgid`, `subject`, `receiver`, `sender`, `message`, `dnumber`) VALUES
(17835, 'Kwasu App', 'queengold', 'olabamiji14', 'This is the application', '4925274732274732492519321141413327151149273937');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `sno` int(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`sno`, `name`, `userid`, `password`) VALUES
(1, 'OLABAMIJI IBRAHIM ISHOLA', 'olabamiji14', 'nd08cspt'),
(2, 'OLABAMIJI HASSANAT', 'queengold', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `decipherkey`
--
ALTER TABLE `decipherkey`
  ADD PRIMARY KEY (`msgid`);

--
-- Indexes for table `encryptedmessage`
--
ALTER TABLE `encryptedmessage`
  ADD PRIMARY KEY (`msgid`);

--
-- Indexes for table `honeydictionary`
--
ALTER TABLE `honeydictionary`
  ADD PRIMARY KEY (`seed`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`msgid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `honeydictionary`
--
ALTER TABLE `honeydictionary`
  MODIFY `seed` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `sno` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
