<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Technology Center</title>
<link href="css/allybajab.css" rel="stylesheet" type="text/css" />
 <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-42831912-1', 'admintech.com.ng');
  ga('send', 'pageview');

</script>
</head>

<body>
<div style="width:100%; margin: 0 auto; height:5px; background-color:#2A3F55;"></div>
<table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th width="405" rowspan="2" align="left" valign="bottom" scope="row"><img src="images/adminlogo.png" width="335" height="69" /></th>
    <th width="496" height="71" scope="row">&nbsp;</th>
  </tr>
  <tr>
    <td height="34" scope="row"><ul class="menu">
      <li><a href="index.php">Home </a></li>
      <li></li>
      <li><a href="#">About Us </a></li>
      <li><a href="#">Services </a></li>
      <li><a href="#">Portfolio</a> </li>
      <li><a href="#">Contact Us</a></li>
      <li><a href="#">Webmail</a></li>
    </ul></td>
  </tr>
  <tr>
    <th height="320" colspan="2" scope="row"><!-- Start WOWSlider.com -->
<iframe src="index2.html" style="width:900px;height:320px;max-width:100%;overflow:hidden;border:none;padding:0;margin:0 auto;display:block;" marginheight="0" marginwidth="0"></iframe>
<!-- End WOWSlider.com --></th>
  </tr>
  <tr>
    <td height="91" colspan="2" align="left" valign="top" scope="row" style="padding:10px;" ><h1>Robust Technologies</h1>
    <p>we are professionals in building capacity and delivering cutting-edge   ICT solutions. Developing, Implementing and Supporting best and cost   effective open source and non open source ICT solutions in Nigeria.</p></td>
  </tr>
  <tr>
    <th height="290" colspan="2" align="left" valign="top" scope="row"><table width="901" border="0" align="center" cellpadding="2" cellspacing="2">
      <tr id="trhead">
        <th width="291" align="left" style=" color:#00FFFF;" scope="row">Software Development</th>
        <td width="277" align="left" style=" color:#00FFFF;">Web Design</td>
        <td width="156" align="left" style=" color:#00FFFF;">Graphics Design</td>
        <td width="151" align="left" nowrap="nowrap" style=" color:#00FFFF;">Computer Training</td>
      </tr>
      <tr height="200">
        <th height="299" bgcolor="#DADADA" scope="row"><p align="left">We are expert in the field developing a stand alone appliccation ranges to mobile apps. We develop applications with the below tools:</p>
          
<p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></th>
        <td bgcolor="#DADADA"><p>We develop website for pesonalities, business and companies to enhance the functionality of their and product and services. </p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          </td>
        <td bgcolor="#DADADA"><p>Corel Graphics, Micromedia Fireworks, Adobe Photoshop.</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p></td>
        <td bgcolor="#E2E2E2"><p>Programming. Desktop Publishing. Database Management.</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          </td>
      </tr>
    </table></th>
  </tr>
  <tr>
    <th height="25" colspan="2" scope="row">&nbsp;</th>
  </tr>
 
</table>
<div id="foot-cont">powered by Robust Technologies</div>
</body>

</html>