<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="915" border="0" cellpadding="4" cellspacing="0">
  <tr bgcolor="#FFECF2">
    <td align="left" valign="top">NAME</td>
    <td width="89"  align="left" valign="top">STATE</td>
    <td width="338"  align="left" valign="top">ADDRESS</td>
    <td colspan="3" align="left" valign="top">Website/Email /Phone No</td>
  </tr>
  <tr>
    <td align="left" valign="top">DA'WAH AND GUIDANCE BUREAU</td>
    <td align="left" valign="top">ABIA</td>
    <td width="338"  align="left" valign="top">DA'WAH AND GUIDANCE BUREAU<br />
      AFIKPO,<br />
      ABIA STATE, , NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr bgcolor="#FFECF2">
    <td align="left" valign="top" bgcolor="#FFECF2">Abuja Muslim Forum</td>
    <td align="left" valign="top" bgcolor="#FFECF2">ABUJA</td>
    <td width="338" align="left" valign="top">Abuja Muslim Forum<br />
      National Mosque Complex, Central Area, Abuja,<br />
      Abuja, Federal Capital Territory 0234, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><p><a href="mailto:abujamuslimforum@gmail.com">abujamuslimforum@gmail.com<br />
    </a>234-08057927142</p></td>
  </tr>
  <tr>
    <td align="left" valign="top">Al Khulafaur Rashidun    Foundation</td>
    <td align="left" valign="top">ABUJA</td>
    <td width="338" align="left" valign="top">Al Khulafaur Rashidun    Foundation<br />
      Ahlu Badr Islamic Centre, Behind Karu Children Centre, Karu FCT.,<br />
      Abuja, FCT P.O. Box 213, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><p><a href="mailto:alklufaurrashidunfoundation@yahoo.com">alklufaurrashidunfoundation@yahoo.com</a></p>
    <p>234-8036883176</p></td>
  </tr>
  <tr bgcolor="#FFECF2">
    <td align="left" valign="top" bgcolor="#FFECF2">Al-habibiyyah islamic    society,masjid</td>
    <td align="left" valign="top" bgcolor="#FFECF2">ABUJA</td>
    <td width="338" align="left" valign="top"> Al-habibiyyah islamic society,masjid<br />
      Plot 753,Guzape District, Asokoro Extension ,<br />
      Abuja, Guzape District, Asokoro exten , NIGERIA<br />
      <br />
    </td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="http://www.al-habibiyyah.org/" target="_blank">http://www.al-habibiyyah.org/<br />
    </a>234-8033147828</td>
  </tr>
  <tr>
    <td align="left" valign="top">BEKAJI ISLAMIC ENTRE</td>
    <td align="left" valign="top">ADAMAWA</td>
    <td width="338" align="left" valign="top"> BEKAJI ISLAMIC ENTRE<br />
      BEKAJI GRA, JIMETA-YOLA,<br />
      Yola, ADAMAWA , NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">FEDERATION OF MUSLIM WOMEN'S    ASSOCIATION IN NIGERIA(FOMWAN)</td>
    <td align="left" valign="top" bgcolor="#FFECF2">ADAMAWA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2"> FEDERATION OF MUSLIM WOMEN'S ASSOCIATION IN    NIGERIA(FOMWAN)<br />
      NO 17 NEPA ROAD JIMETA YOLA,<br />
      Yola, ADAMAWA 234, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:fomwanjimetayola@yahoo.com">fomwanjimetayola@yahoo.com<br />
    </a>234-08053459746</td>
  </tr>
  <tr>
    <td align="left" valign="top">Almufida orphans organisation    gumau</td>
    <td align="left" valign="top">BAUCHI</td>
    <td width="338" align="left" valign="top">Almufida orphans organisation    gumau<br />
      wunti street gumau bauchi state,<br />
      Bauchi State, bauchi 740004, NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:almufidagumau@yahoo.com">almufidagumau@yahoo.com</a><br />
    +23480551938492,</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Madarasatul Targibul Islam</td>
    <td align="left" valign="top" bgcolor="#FFECF2">BAUCHI</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Madarasatul Targibul Islam<br />
      Unguwar Ilela,<br />
      Bauchi, Bauchi , NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"></td>
  </tr>
  <tr>
    <td align="left" valign="top">Islamic Propagation Group    (IPG)</td>
    <td align="left" valign="top">BAYELSA</td>
    <td width="338" align="left" valign="top"> Islamic Propagation Group (IPG)<br />
      C/o Akmpai Centrel Mosque, Akempai, Yenagoa,<br />
      Yenagoa, Bayelsa 089, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top">+2348063372009</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Islamic Charity Society of    Nigeria</td>
    <td align="left" valign="top" bgcolor="#FFECF2">benue</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2"> 1.Islamic Charity Society of Nigeria<br />
      No. 43 Niger Crescent, Wadata, Makurdi,<br />
      Makurdi, Benue , NIGERIA <br />
      <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><p><a href="mailto:icsonigeria@yahoo.com">icsonigeria@yahoo.com</a><br />
    +2347066883792</p></td>
  </tr>
  <tr>
    <td align="left" valign="top">Al Amin Islamic Foundation</td>
    <td align="left" valign="top">BORNO</td>
    <td width="338" align="left" valign="top">Al Amin Islamic Foundation<br />
      N0 1 EL-KANEMI CLOSE, OFF CIRCULAR ROAD, OLD G.R.A. MAIDUGURI.,<br />
      , BORNO STATE , NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:alaminislamic@yahoo.com">alaminislamic@yahoo.com</a><br />
    +234 76 230156</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Khalid Ibn Walid Islamic    School</td>
    <td align="left" valign="top" bgcolor="#FFECF2">BORNO</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2"> Khalid Ibn Walid Islamic School<br />
      Umarari/Ngarannam, Bolori II ward.,<br />
      Maiduguri, Borno 234, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:kiwis1997@yahoo.com">kiwis1997@yahoo.com<br />
    </a></td>
  </tr>
  <tr>
    <td align="left" valign="top">Muslim Corpers Association of    Nigeria</td>
    <td align="left" valign="top">EBONYI</td>
    <td width="338" align="left" valign="top">Muslim Corpers Association of    Nigeria<br />
      Hausa Quarters, Along Afikpo Road,<br />
      Abakaliki, Ebonyi State , NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:mcaan@yahoo.com">mcaan@yahoo.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">ANSAR-UD-DEEN SOCIETY OF    NIGERIA. IKERE BRANCH</td>
    <td align="left" valign="top" bgcolor="#FFECF2">EKITI</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">ANSAR-UD-DEEN SOCIETY OF    NIGERIA. IKERE BRANCH<br />
      P.O.BOX 54,<br />
      Ikere-ekiti, EKITI-STATE , NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2">+2348034797823</td>
  </tr>
  <tr>
    <td align="left" valign="top">Iislamic reliefs foundation</td>
    <td align="left" valign="top">EKITI</td>
    <td width="338" align="left" valign="top"> Iislamic reliefs foundation<br />
      albarka shop 8 sergi shopping complex beside AUD central mosque Ado    ekiti,<br />
      Ado, 234 p.o box 1443, NIGERIA<br />
      <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="mailto:saeedawo@yahoo.com">saeedawo@yahoo.com</a><br />
    234-08038810388</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">DAARUL HADITH ISLAMIC CENTRE</td>
    <td align="left" valign="top" bgcolor="#FFECF2">GOMBE</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">DAARUL HADITH ISLAMIC    CENTRE<br />
      BOMALA BYE PASS,<br />
      Gombe, GOMBE , NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2">-30206056</td>
  </tr>
  <tr>
    <td width="146" align="left" valign="top">Bakinkasuwa    islamic foundation <br />
      <br /></td>
    <td align="left" valign="top">JIGAWA</td>
    <td width="338" align="left" valign="top">Bakinkasuwa islamic    foundation<br />
      Bakinkasuwa, kazaure,<br />
      Kazaure, jigawa state Kazaure, NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:maskaz246@hotmail.com">maskaz246@hotmail.com<br />
    </a>064-680020</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">SIRAJA GWIWA ISLAMIC    FOUNDATION</td>
    <td align="left" valign="top" bgcolor="#FFECF2">JIGAWA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">SIRAJA GWIWA ISLAMIC    FOUNDATION<br />
      UNGUWAR MALAMAI,<br />
      Gwiwa, JIGAWA STATE GWIWA TOWN, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><p><a href="mailto:SIRAJAGWIWA@YAHOO.COM">SIRAJAGWIWA@YAHOO.COM</a><br />
    +2348035985068</p></td>
  </tr>
  <tr>
    <td align="left" valign="top">Dawakin Bassa Daawah Group</td>
    <td align="left" valign="top">KADUNA</td>
    <td width="338" align="left" valign="top">Dawakin Bassa Daawah Group<br />
      Dawakin Bassa BGLGA Kaduna,<br />
      Birnin Gwari Native Area Number 1, Kaduna , NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:dbassa_1970@yahoo.com">dbassa1970@yahoo.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top">Iqra'a Foundation</td>
    <td align="left" valign="top">KADUNA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Iqra'a Foundation<br />
      16 Ishaku Road, Malali,<br />
      Kaduna, Kaduna , NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"></td>
  </tr>
  <tr>
    <td align="left" valign="top">Abubakar Siddiq Islamic    Foundation</td>
    <td align="left" valign="top">KANO</td>
    <td width="338" align="left" valign="top">Abubakar Siddiq Islamic    Foundation<br />
      Briget Gama kano city,<br />
      Kano, Kano 123, NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:sasif06@hotmail.cm">sasif06@hotmail.cm</a><br />
    080-36933571</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">BDE ISLAMIC CENTRE</td>
    <td align="left" valign="top" bgcolor="#FFECF2">KANO</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">BDE ISLAMIC CENTRE<br />
      gyadi/gyadi Zaria Road,<br />
      Kano, Kano 700001, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:abdulsaad61@yahoo.com">abdulsaad61@yahoo.com</a><br />
    +2348096300443</td>
  </tr>
  <tr>
    <td align="left" valign="top">AbuZur Islamic Propagation    and Empowerment Centre, Katsiina</td>
    <td align="left" valign="top">KATSINA</td>
    <td width="338" align="left" valign="top">AbuZur Islamic Propagation and    Empowerment Centre, Katsiina<br />
      Katsina,<br />
      Katsina, Katsina P.O Box 1322, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:abuzaraipeck@yahoo.com">abuzaraipeck@yahoo.com</a><br />
    +2348035077007</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">AMINA ISLAMIC FOUNDATION</td>
    <td align="left" valign="top" bgcolor="#FFECF2">KOGI</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2"> AMINA ISLAMIC FOUNDATION<br />
      42B KARAWORO STREET,<br />
      Lokoja, KOGI 234, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:tijjaniisah@yahoo.com">tijjaniisah@yahoo.com<br />
    </a>080-23638203</td>
  </tr>
  <tr>
    <td align="left" valign="top">AMINA ISLAMIC FOUNDATION</td>
    <td align="left" valign="top">KOGI</td>
    <td width="338" align="left" valign="top"> AMINA ISLAMIC FOUNDATION<br />
      42B KARAWORO STREET,<br />
      Lokoja, KOGI 234, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="mailto:tijjaniisah@yahoo.com">tijjaniisah@yahoo.com</a><br />
    080-23638203</td>
  </tr>
  <tr>
    <td width="146" align="left" valign="top" bgcolor="#FFECF2">Centre    Forlamic Islamic Affairs of Nigeria <br />
      <br /></td>
    <td align="left" valign="top" bgcolor="#FFECF2">KOGI </td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Centre Forlamic Islamic Affairs    of Nigeria<br />
      No.1 Mubarak Close Ege,Adavi,<br />
      Kogi State, Kogi 264103, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:mubarakege@gmail.com">mubarakege@gmail.com</a><br />
    234-08032304250</td>
  </tr>
  <tr>
    <td align="left" valign="top">Ahbabud-dinil Islami Society    of Nigeria,Offa Garage, Ilorin</td>
    <td align="left" valign="top">KWARA</td>
    <td width="338" align="left" valign="top">Ahbabud-dinil Islami Society of    Nigeria,Offa Garage, Ilorin.<br />
      Ojomu Estate,Offa Garage,Ilorin.,<br />
      Illorin, Kwara 20004, NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:ahbabudin@yahoo.org">ahbabudin@yahoo.org</a><br />
    0805-5679094</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Ajarat Islamic Thought    Foundation</td>
    <td align="left" valign="top" bgcolor="#FFECF2">KWARA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Ajarat Islamic Thought    Foundation<br />
      suite 95, stadium shopping complex,Ibrahim Taiwo Road Ilorin,<br />
      Ilorin, Kwara state 234, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:psaheed2003@yahoo.com">psaheed2003@yahoo.com</a>  <br />
    080-34727717 </td>
  </tr>
  <tr>
    <td align="left" valign="top">Al Fatih-ul Quareeb Islamic    Society Of Nigeria</td>
    <td align="left" valign="top">KWARA</td>
    <td width="338" align="left" valign="top"> Al Fatih-ul Quareeb Islamic Society Of    Nigeri<br />
      Atobiloye mosque,Atobilote compund.Oke Ode,<br />
      Oke Ode, Kwara , NIGERIA<br />
      <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="http://al-fatih-ul-quareeb.com/" target="_blank">al-fatih-ul-quareeb.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">ALQIBLAH INTERNATIONAL    PROMOTION ILORIN</td>
    <td align="left" valign="top" bgcolor="#FFECF2">KWARA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">ALQIBLAH INTERNATIONAL PROMOTION    ILORIN<br />
      29, pakata road okekura ilorin,<br />
      Ilorin, Kwara 24001, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:freewill2paradise@hotmail.com">freewill2paradise@hotmail.com</a><br />
    234-8042259691</td>
  </tr>
  <tr>
    <td align="left" valign="top">CRESCENT ISLAMIC CENTRE</td>
    <td align="left" valign="top">KWARA</td>
    <td width="338" align="left" valign="top">CRESCENT ISLAMIC CENTRE<br />
      ILORIN,<br />
      KWARA STATE, , NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Fagba Muslim Community,Ilorin</td>
    <td align="left" valign="top" bgcolor="#FFECF2">KWARA</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Fagba Muslim    Community,Ilorin<br />
      No7 Fagba street,<br />
      Ilorin, Kwara P.O BOX 4529, NIGERIA <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:fagbamuslimcom@yahoo.com">fagbamuslimcom@yahoo.com<br />
    </a>234-031229779</td>
  </tr>
  <tr>
    <td align="left" valign="top">Aaqibat lil mutaqeen society    of Nigeria</td>
    <td align="left" valign="top">LAGOS</td>
    <td width="338" align="left" valign="top">Aaqibat lil mutaqeen society of    Nigeria<br />
      16, Alhaji Muili street, Oregun,<br />
      Lagos, Ikeja, Lagos 234-01, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:lilmutaqeen@yahoo.com">lilmutaqeen@yahoo.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Abdul Azeez Islamic Foundation    Mosque</td>
    <td align="left" valign="top" bgcolor="#FFECF2">LAGOS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Abdul Azeez Islamic Foundation    Mosque<br />
      Unity Estate Abule Odu Egbeda,<br />
      Lagos, Lagos 234, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:latsonazeez@yahoo.com">latsonazeez@yahoo.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top">Abdul Razaq Islamic Foundation</td>
    <td align="left" valign="top">LAGOS</td>
    <td width="338" align="left" valign="top"> Abdul Razaq Islamic Foundation<br />
      agbado, Lagos,<br />
      Lagos State, Lagos 2341, NIGERIA<br />
      <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="mailto:abdulrazaq.edrees@yahoo.com">abdulrazaq.edrees@yahoo.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Al-Ameen Islamic Foundation</td>
    <td align="left" valign="top" bgcolor="#FFECF2">LAGOS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Al-Ameen Islamic Foundation</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:almislf@yahoo.com">almislf@yahoo.com</a><br />
    23480-38179404</td>
  </tr>
  <tr>
    <td align="left" valign="top">Albushrah islamic foundation</td>
    <td align="left" valign="top">LAGOS</td>
    <td width="338" align="left" valign="top">Albushrah islamic    foundation<br />
      no 1 otunuyi street agbede ikorodu lagos nigeria,<br />
      Lagos, lagos , NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:albushrah%20_IF">albushrah _IF<br />
    0</a>8055408782</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">ALMUSBAH ISLAMIC FOUNDATION</td>
    <td align="left" valign="top" bgcolor="#FFECF2">LAGOS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">ALMUSBAH ISLAMIC    FOUNDATION<br />
      3, OLANREWAJU CRESCENT, SHASHA, AGEGE,<br />
      Lagos, , NIGERIA <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2">00234-1-522812</td>
  </tr>
  <tr>
    <td align="left" valign="top">Zumratul islamiyyah amuwo    odofin branch mile2 lagos</td>
    <td align="left" valign="top">LAGOS</td>
    <td width="338" align="left" valign="top"> <br />
      Zumratul islamiyyah amuwo odofin branch mile2 lagos<br />
      Block 72 mile2 lagos,<br />
      Lagos-Ikeja, Lagos 23401, NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:abdulazeez_alugo@yahoo.com">abdulazeezalugo@yahoo.com</a><br />
    08023-169827</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Zuratul Islamiyah society of    Nigeria</td>
    <td align="left" valign="top" bgcolor="#FFECF2">LAGOS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Zuratul Islamiyah society of    Nigeria<br />
      2 Tawaliu Bello street,<br />
      Lagos Island, Lagos State , NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"></td>
  </tr>
  <tr>
    <td width="146" align="left" valign="top">FADIMATU    BAKAYA ASSALAFIYA <br />
      <br /></td>
    <td align="left" valign="top">NIGER</td>
    <td width="338" align="left" valign="top">FADIMATU BAKAYA ASSALAFIYA<br />
      DADIN KOWA,<br />
      Kontagora, , NIGERIA <br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:abusurayya2@yahoo.com">abusurayya2@yahoo.co<br />
    </a>8036237058</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Ar-rahman Islamic Foundation</td>
    <td align="left" valign="top" bgcolor="#FFECF2">OGUN</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Ar-rahman Islamic    Foundation<br />
      Gbonagun Junction,Odo Eran , Obantoko, Abeokuta, Ogun State, Nigeria,<br />
      Abeokuta, Ogun State P.O.BOX 4031, SAPON, NIGERIA <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:abuzainab1425@islam.com">abuzainab1425@islam.com</a><br />
    23480-33485212</td>
  </tr>
  <tr>
    <td align="left" valign="top">Zulikha Abiola Arabic and    Islamic Center</td>
    <td align="left" valign="top">OGUN</td>
    <td width="338" align="left" valign="top">Zulikha Abiola Arabic and    Islamic Center<br />
      Abiola Way,Abeokuta,<br />
      Abeokuta, Ogun State 039, NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:uthjaji@yahoo.co.uk">uthjaji@yahoo.co.uk</a><br />
    08033352906</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Ajegunle Islamic and Arabic    Centre</td>
    <td align="left" valign="top" bgcolor="#FFECF2">OSUN</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Ajegunle Islamic and Arabic    Centre<br />
      Ajegunle Area, Iragbiji.,<br />
      Iragbiji, Osun State. , NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:oloyedeabdulateef@yahoo.com">oloyedeabdulateef@yahoo.com</a><br />
    07034442784</td>
  </tr>
  <tr>
    <td align="left" valign="top">AL FATHIA</td>
    <td align="left" valign="top">OSUN</td>
    <td colspan="2" align="left" valign="top">AL FATHIA OAU CAMPUS, IFE OSUN    STATE, NIGERIA</td>
    <td width="309" colspan="2" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">AL-QUDUS ISLAMIC INFORMATION    CENTRE (CYBER CAFE)</td>
    <td align="left" valign="top" bgcolor="#FFECF2">OSUN</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">AL-QUDUS ISLAMIC INFORMATION    CENTRE (CYBER CAFE)<br />
      NO24D, BEHIND WEMA BANK PLC., IWO, ,<br />
      Iwo, OSUN 23402, NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="http://www.quduscentrenigeria.net/" target="_blank">http://www.quduscentrenigeria.net/<br />
    </a><a href="mailto:alqudusinfo241205@yahoo.com">alqudusinfo241205@yahoo.com</a> <br />
+2348-030972339 </td>
  </tr>
  <tr>
    <td align="left" valign="top">AFRICA MUSLIM AGENCY</td>
    <td align="left" valign="top">OYO</td>
    <td width="338" align="left" valign="top">AFRICA MUSLIM AGENCY<br />
      PoBox 18 , AYETORO OKEHO,<br />
      Oyo State, , NIGERIA</td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Ahlsunnah islamic foundation</td>
    <td align="left" valign="top" bgcolor="#FFECF2">OYO</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Ahlsunnah islamic    foundation<br />
      G.P.O. BOX 16302 DUGBE ibadan,<br />
    Ibadan, oyo state 23402, NIGERIA</td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:ahlsunnah1424@hotmail.com">ahlsunnah1424@hotmail.com</a><br />
    02-2319878</td>
  </tr>
  <tr>
    <td align="left" valign="top">Al akhilau fil jannat</td>
    <td align="left" valign="top">OYO</td>
    <td width="338" align="left" valign="top"> Al akhilau fil jannat<br />
      L Adisa mosque Agbowo ui Ibadan oyo state Nigeria,<br />
      Ibadan, oyo 234, NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="mailto:alakhilau2@yahoo.co.uk">alakhilau2@yahoo.co.<br />
    uk</a>00234-8033797625</td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Al-Nuru Islamic Centre Iseyin</td>
    <td align="left" valign="top" bgcolor="#FFECF2">OYO</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Al-Nuru Islamic Centre    Iseyin<br />
      Olohunlonigba Villa Amoko Iseyin,<br />
      Iseyin, oyo 234, NIGERIA <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:olohunlonigba@gmail.com">olohunlonigba@gmail.com</a></td>
  </tr>
  <tr>
    <td align="left" valign="top">Ansarudeen society of nigeria    ogbomoso branch</td>
    <td align="left" valign="top">OYO</td>
    <td width="338" align="left" valign="top">Ansarudeen society of nigeria    ogbomoso branch<br />
      P.o.box 132,<br />
      Ogbomoso, oyo lautech road stadium, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"><a href="mailto:adsogbomoso@yahoo.com">adsogbomoso@yahoo.com</a> <br />
    234-8034248169 </td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Al-bayyan Islamic Foundation</td>
    <td align="left" valign="top" bgcolor="#FFECF2">RIVERS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Al-bayyan Islamic    Foundation<br />
      FCE(Technical)Omoku Town,<br />
      Port Harcourt, (Omoku) Rivers State 234, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:al_bayyan_islam@yahoo.com">albayyanislam@yahoo.com</a>  <br />
    8066008071, 60859504 </td>
  </tr>
  <tr>
    <td align="left" valign="top">Al-Usrah</td>
    <td align="left" valign="top">RIVERS</td>
    <td width="338" align="left" valign="top"> Al-Usrah<br />
      Opposite Jaros base, Off Rumuolumeni (Wimpey) Road,,<br />
      Port, Rivers State 600019, NIGERIA<br />
      <br />
    </td>
    <td colspan="3" align="left" valign="top"><a href="http://www.al-usrah.org/" target="_blank">http://www.al-usrah.org/</a><a href="mailto:abdulrazaqkilani@yahoo.com">abdulrazaq<br />
    kilani@yahoo.com</a><br />
    0
    8037029180</td>
  </tr>
  <tr bgcolor="#FFECF2">
    <td align="left" valign="top">Bonny Muslim Community</td>
    <td align="left" valign="top">RIVERS</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2"> Bonny Muslim Community<br />
      Bonny Central Mosque, Bonny Island,<br />
      Bonny, Rivers State , NIGERIA <br />
    </td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top">CENTER FOR ISLAMIC STUDIES</td>
    <td align="left" valign="top">SOKOTO</td>
    <td width="338" align="left" valign="top">CENTER FOR ISLAMIC STUDIES<br />
      USMANU DANFODIO UNIVERSITY,<br />
      Sokoto, Sokoto 234, NIGERIA<br /></td>
    <td colspan="3" align="left" valign="top"></td>
  </tr>
  <tr>
    <td align="left" valign="top" bgcolor="#FFECF2">Fudiyya Islamic Centre, Nguru,    Yobe State.</td>
    <td align="left" valign="top" bgcolor="#FFECF2">YOBE</td>
    <td width="338" align="left" valign="top" bgcolor="#FFECF2">Fudiyya Islamic Centre, Nguru,    Yobe State.<br />
      Nayi-nawa ward.,<br />
      Nguru, Yobe , NIGERIA<br />
      <br /></td>
    <td colspan="3" align="left" valign="top" bgcolor="#FFECF2"><a href="mailto:mgknguru@yahoo.com">mgknguru@yahoo.com</a><br />
    08065464275</td>
  </tr>
  <tr>
    <td align="left" valign="top">Madarasatus Rahamaniya </td>
    <td align="left" valign="top">ZAMFARA</td>
    <td width="338" align="left" valign="top">Madarasatus Rahamaniya <br />
      Filin magajiya Sabon fegi area Gusau.,<br />
      Gusau, Zamfara , NIGERIA</td>
    <td colspan="3" align="left" valign="top"><a href="mailto:abanusaiba@yahoo.com">abanusaiba@yahoo.com</a><br />
      08064458812</td>
  </tr>
</table>
</body>
</html>